#include "button.h"
#include "lpc17xx.h"

#include "../led/led.h"

extern unsigned char next_state(unsigned char current_state, unsigned char taps, int *output_bit);
volatile unsigned char current_state = 0xAA;					// in binario: 10101010
volatile unsigned char taps = 0x1D;										// in binario: 00011101
volatile int output_bit = 0;

void EINT0_IRQHandler (void)	  
{
	LED_On(0);
  LPC_SC->EXTINT &= (1 << 0);     /* clear pending interrupt         */
}


void EINT1_IRQHandler (void)	  
{
	int i;
	for (i = 0; i < 8; i++) LED_Off(i);		// spengo tutti i led
	current_state = next_state(current_state, taps, &output_bit);
	
	LED_Out(current_state);					// visualizzo lo state sui LED
	LPC_SC->EXTINT &= (1 << 1);     /* clear pending interrupt         */
}

void EINT2_IRQHandler (void)	  
{
	LED_Off(0);
	LED_Off(1);
  LPC_SC->EXTINT &= (1 << 2);     /* clear pending interrupt         */    
}


